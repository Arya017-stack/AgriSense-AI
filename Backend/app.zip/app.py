from flask import Flask ,request, jsonify
from flask_cors import CORS 
import os
import easyocr

reader = easyocr.Reader(['en'])

app =Flask(__name__)
CORS(app)

UPLOAD_FOLDER ="uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app.config["UPLOAD_FOLDER"] =UPLOAD_FOLDER

@app.route("/")
def home():
    return{
        "message":"AgriSense AI Backend Running 🚀"
    }

@app.route("/upload", methods=["POST"])
def upload_receipt():
    print("UPLOAD API CALLED")

    if "receipt" not in request.files:
        return jsonify({"error": "No file uploaded"}),400
    file = request.files["receipt"]

    if file.filename =="":  
        return jsonify({"error":"No selected file"}), 400
    filepath = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)

    file.save(filepath)

    print("Saving done")
    
    print("Starting OCR")

    import time

    try:
        start = time.time()

        result = reader.readtext(filepath, detail=0)

        end = time.time()

        print("OCR TIME:", end - start)
        print("OCR Finished")

        extracted_text = "\n".join(result)

        return jsonify({
            "message": "Receipt uploaded successfully",
            "filename": file.filename,
            "text": extracted_text
    })

    except Exception as e:
        print("OCR ERROR:", e)

        return jsonify({
            "error": str(e)
        }), 500

if __name__ =="__main__":
    app.run(debug=True)

